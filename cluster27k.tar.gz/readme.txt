License : 

    This work is licensed under a Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License.
    For commerical use contact rajasankar@naturaltext.com or @rajasankar

Info about the files

cluster_27k_data.json -- 27k protein data downloaded from NCBI
format : name -- name of the protein
            sequence -- aminoacid sequence

cluster_27k.json -- Hierarchical Clustering data for 27k data
format : cat : category name : simiarltiy %
            protein names : list of protein names for that cluster

cluster_27k_tax.txt -- taxnomical style formated data for the 27k data. 

cluster_7M.json --- Hierarchical Clustering data for 7 Million proteins
    data for this here ftp://ftp.ncbi.nlm.nih.gov/blast/db/FASTA/env_nr.gz
    format : cat : category name : simiarltiy %
                protein names : list of protein names for that cluster

    

